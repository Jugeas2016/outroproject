./fmedia-1/fmedia song.mp3
poweroff
