./fmedia-1/fmedia song.mp3 | shutdown -P 1
